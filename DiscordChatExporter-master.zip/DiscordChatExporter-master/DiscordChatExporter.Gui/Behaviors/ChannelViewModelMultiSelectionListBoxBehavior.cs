﻿using DiscordChatExporter.Gui.ViewModels.Components;

namespace DiscordChatExporter.Gui.Behaviors
{
    public class ChannelViewModelMultiSelectionListBoxBehavior : MultiSelectionListBoxBehavior<ChannelViewModel>
    {
    }
}