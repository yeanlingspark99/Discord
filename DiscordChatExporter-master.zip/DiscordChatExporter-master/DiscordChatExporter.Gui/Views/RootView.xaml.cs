﻿namespace DiscordChatExporter.Gui.Views
{
    public partial class RootView
    {
        public RootView()
        {
            InitializeComponent();
        }
    }
}