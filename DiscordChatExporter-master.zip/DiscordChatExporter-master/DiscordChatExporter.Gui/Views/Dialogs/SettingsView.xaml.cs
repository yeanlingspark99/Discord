﻿namespace DiscordChatExporter.Gui.Views.Dialogs
{
    public partial class SettingsView
    {
        public SettingsView()
        {
            InitializeComponent();
        }
    }
}