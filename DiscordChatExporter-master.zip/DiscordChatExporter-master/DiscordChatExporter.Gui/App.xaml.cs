﻿namespace DiscordChatExporter.Gui
{
    public partial class App
    {
    }
}