﻿namespace DiscordChatExporter.Core.Markdown.Nodes
{
    public abstract class Node
    {
    }
}