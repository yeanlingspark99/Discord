﻿namespace DiscordChatExporter.Core.Markdown.Nodes
{
    public enum MentionType
    {
        Meta,
        User,
        Channel,
        Role
    }
}