﻿namespace DiscordChatExporter.Core.Markdown.Nodes
{
    public enum TextFormatting
    {
        Bold,
        Italic,
        Underline,
        Strikethrough,
        Spoiler,
        Quote
    }
}