﻿namespace DiscordChatExporter.Core.Models
{
    public enum ExportFormat
    {
        PlainText,
        HtmlDark,
        HtmlLight,
        Csv
    }
}