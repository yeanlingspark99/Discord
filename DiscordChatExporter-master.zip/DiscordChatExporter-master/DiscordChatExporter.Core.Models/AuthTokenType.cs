﻿namespace DiscordChatExporter.Core.Models
{
    public enum AuthTokenType
    {
        User,
        Bot
    }
}